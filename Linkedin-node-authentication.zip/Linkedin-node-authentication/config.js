module.exports = {
    'linkedinAuth': {
      'clientID': '78rob873lxt1os', // your App ID
      'clientSecret': 'JGZnV78gRmUdnMuX', // your App Secret
      'callbackURL': 'http://127.0.0.1:3000/auth/linkedin/callback'
      
      
    }
  }